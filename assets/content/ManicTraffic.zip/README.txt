To play the game simply run the batch file located here.
